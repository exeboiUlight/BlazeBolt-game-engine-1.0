-- ==========================================
-- BlazeBolt Unity-like Runtime API
-- Provides GameObject, Transform, Components
-- ==========================================

-- Internal registry: entity -> { gameObject, componentType }
local entityRegistry = {}

-- ==========================================
-- Time (static)
-- ==========================================
Time = {
    _deltaTime = 0,
    _time = 0,
    _scale = 1,
    _frameCount = 0
}

function Time:GetDeltaTime()
    return self._deltaTime * self._scale
end

function Time:GetUnscaledDeltaTime()
    return self._deltaTime
end

function Time:GetTime()
    return self._time
end

function Time:GetFrameCount()
    return self._frameCount
end

function Time:SetScale(s)
    self._scale = s
end

function Time:GetScale()
    return self._scale
end

-- ==========================================
-- Mathf (static)
-- ==========================================
Mathf = {
    PI = 3.14159265358979323846,
    Deg2Rad = 0.017453292519943295,
    Rad2Deg = 57.29577951308232,
    Epsilon = 1.1920928955078125e-7
}

function Mathf:Abs(v) return math.abs(v) end
function Mathf:Floor(v) return math.floor(v) end
function Mathf:Ceil(v) return math.ceil(v) end
function Mathf:Round(v) return math.floor(v + 0.5) end
function Mathf:Clamp(v, mn, mx) return math.max(mn, math.min(mx, v)) end
function Mathf:Lerp(a, b, t) return a + (b - a) * t end
function Mathf:InverseLerp(a, b, v)
    if math.abs(b - a) < self.Epsilon then return 0 end
    return (v - a) / (b - a)
end
function Mathf:Sqrt(v) return math.sqrt(v) end
function Mathf:Sin(v) return math.sin(v) end
function Mathf:Cos(v) return math.cos(v) end
function Mathf:Tan(v) return math.tan(v) end
function Mathf:ASin(v) return math.asin(v) end
function Mathf:ACos(v) return math.acos(v) end
function Mathf:ATan(v) return math.atan(v) end
function Mathf:ATan2(y, x) return math.atan2(y, x) end
function Mathf:Sign(v) return v >= 0 and 1 or -1 end
function Mathf:Min(a, b) return math.min(a, b) end
function Mathf:Max(a, b) return math.max(a, b) end
function Mathf:Pow(b, e) return b ^ e end
function Mathf:Exp(v) return math.exp(v) end
function Mathf:Log(v) return math.log(v) end
function Mathf:Log10(v) return math.log(v, 10) end
function Mathf:Repeat(t, length) return t - math.floor(t / length) * length end
function Mathf:PingPong(t, length)
    t = self:Repeat(t, length * 2)
    return length - math.abs(t - length)
end
function Mathf:DeltaAngle(current, target)
    local diff = self:Repeat(target - current, 360)
    if diff > 180 then diff = diff - 360 end
    return diff
end
function Mathf:LerpAngle(a, b, t)
    return a + self:DeltaAngle(a, b) * t
end
function Mathf:MoveTowards(current, target, maxDelta)
    if math.abs(target - current) <= maxDelta then return target end
    return current + self:Sign(target - current) * maxDelta
end
function Mathf:Clamp01(v) return self:Clamp(v, 0, 1) end
function Mathf:LerpUnclamped(a, b, t) return a + (b - a) * t end
function Mathf:SmoothStep(from, to, t)
    t = self:Clamp01(t)
    t = t * t * (3 - 2 * t)
    return from + (to - from) * t
end
function Mathf:Approximately(a, b)
    return math.abs(b - a) < math.max(self.Epsilon, math.max(math.abs(a), math.abs(b)) * self.Epsilon * 8)
end

-- ==========================================
-- Input (static)
-- ==========================================
Input = {
    _anyKey = false,
    _anyKeyDown = false,
    _mousePosition = Vector2(0, 0),
    _mouseScrollDelta = Vector2(0, 0),
    _mouseButtons = {},
    _keys = {},
    _keysDown = {},
    _keysUp = {},
    _axis = {
        Horizontal = { negative = Keys.A, positive = Keys.D, altNegative = Keys.LEFT, altPositive = Keys.RIGHT, value = 0 },
        Vertical = { negative = Keys.S, positive = Keys.W, altNegative = Keys.DOWN, altPositive = Keys.UP, value = 0 },
        Fire1 = { button = 0, value = false },
        Fire2 = { button = 1, value = false },
        Fire3 = { button = 2, value = false }
    }
}

function Input:GetKey(keyCode)
    return BlazeBolt.IsKeyPressed(keyCode)
end

function Input:GetKeyDown(keyCode)
    return BlazeBolt.IsKeyJustPressed(keyCode)
end

function Input:GetMouseButton(button)
    return BlazeBolt.IsMouseButtonPressed(button)
end

function Input:GetMouseButtonDown(button)
    return BlazeBolt.IsMouseButtonJustPressed(button)
end

function Input:GetAxis(axisName)
    local axis = self._axis[axisName]
    if not axis then return 0 end
    if axis.positive then
        local positive = (self:GetKey(axis.positive) and 1 or 0) + (axis.altPositive and self:GetKey(axis.altPositive) and 1 or 0)
        local negative = (self:GetKey(axis.negative) and 1 or 0) + (axis.altNegative and self:GetKey(axis.altNegative) and 1 or 0)
        return math.min(1, positive) - math.min(1, negative)
    end
    if axis.button then
        return self:GetMouseButton(axis.button) and 1 or 0
    end
    return 0
end

function Input:GetMousePosition()
    return Vector2(BlazeBolt.GetMouseX(), BlazeBolt.GetMouseY())
end

function Input:GetMouseDelta()
    return Vector2(BlazeBolt.GetMouseDeltaX(), BlazeBolt.GetMouseDeltaY())
end

-- ==========================================
-- Random (static)
-- ==========================================
Random = {
    _state = {}
}

function Random:Init(seed)
    if seed then
        BlazeBolt.SetRandomSeed(seed)
        math.randomseed(seed)
    end
end

function Random:Range(min, max)
    if type(min) == "number" and type(max) == "number" then
        if min > max then min, max = max, min end
        return min + (max - min) * BlazeBolt.Random()
    end
    return BlazeBolt.Random()
end

function Random:RangeInt(min, max)
    if min > max then min, max = max, min end
    return BlazeBolt.RandomInt(min, max)
end

function Random:Value()
    return BlazeBolt.Random()
end

-- ==========================================
-- SceneManager (static)
-- ==========================================
SceneManager = {}

function SceneManager:LoadScene(name)
    BlazeBolt.LoadScene(name)
end

function SceneManager:GetCurrentScene()
    return BlazeBolt.GetCurrentScene()
end

-- ==========================================
-- Component base class
-- ==========================================
Component = {}

function Component:New(obj)
    obj = obj or {}
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function Component:Awake() end
function Component:Start() end
function Component:Update(dt) end
function Component:OnDestroy() end

-- ==========================================
-- Transform
-- ==========================================
Transform = {}

function Transform:New(gameObject)
    local t = {
        _go = gameObject,
        _position = Vector2(0, 0),
        _rotation = 0,
        _scale = Vector2(1, 1)
    }
    setmetatable(t, self)
    self.__index = self
    return t
end

function Transform:GetPosition()
    return self._position
end

function Transform:SetPosition(pos)
    self._position = pos
    if self._go._entity and self._go._entity > 0 then
        if self._go._type == "sprite" then
            BlazeBolt.SpriteSetPosition(self._go._entity, pos)
        elseif self._go._type == "animated_sprite" then
            BlazeBolt.AnimatedSpriteSetPosition(self._go._entity, pos)
        elseif self._go._type == "text" then
            BlazeBolt.TextSetPosition(self._go._entity, pos)
        elseif self._go._type == "camera" then
            BlazeBolt.CameraSetPosition(self._go._entity, pos)
        elseif self._go._type == "particle_system" then
            BlazeBolt.ParticleSystemSetPosition(self._go._entity, pos)
        elseif self._go._type == "tileset" then
            BlazeBolt.TilesetSetPosition(self._go._entity, pos)
        elseif self._go._type == "point_light" then
            BlazeBolt.LightSetPosition(self._go._entity, pos)
        end
    end
    return self
end

function Transform:GetRotation()
    return self._rotation
end

function Transform:SetRotation(rot)
    self._rotation = rot
    if self._go._entity and self._go._entity > 0 then
        if self._go._type == "sprite" then
            BlazeBolt.SpriteSetRotation(self._go._entity, rot)
        elseif self._go._type == "animated_sprite" then
            BlazeBolt.AnimatedSpriteSetRotation(self._go._entity, rot)
        elseif self._go._type == "text" then
            BlazeBolt.TextSetRotation(self._go._entity, rot)
        elseif self._go._type == "camera" then
            BlazeBolt.CameraSetRotation(self._go._entity, rot)
        end
    end
    return self
end

function Transform:GetScale()
    return self._scale
end

function Transform:SetScale(s)
    self._scale = s
    if self._go._entity and self._go._entity > 0 then
        if self._go._type == "sprite" then
            BlazeBolt.SpriteSetSize(self._go._entity, s)
        elseif self._go._type == "animated_sprite" then
            BlazeBolt.AnimatedSpriteSetSize(self._go._entity, s)
        elseif self._go._type == "text" then
            BlazeBolt.TextSetScale(self._go._entity, s)
        end
    end
    return self
end

function Transform:GetLocalPosition()
    local e = self._go._entity
    if e and e > 0 then
        local p = BlazeBolt.NodeGetWorldPosition(e)
        return p
    end
    return self._position
end

function Transform:SetParent(parent, worldPositionStays)
    local e = self._go._entity
    local pe = parent and parent._entity or 0
    if e and e > 0 then
        if pe and pe > 0 then
            if worldPositionStays then
                local wp = self:GetLocalPosition()
                BlazeBolt.NodeSetParent(e, pe)
                self:SetPosition(wp)
            else
                BlazeBolt.NodeSetParent(e, pe)
            end
        else
            BlazeBolt.NodeSetParent(e, 0)
        end
    end
end

-- Property-style access
Transform.__index = function(tbl, key)
    local raw = Transform[key]
    if raw then return raw end
    if key == "position" then
        return tbl:GetPosition()
    elseif key == "rotation" then
        return tbl:GetRotation()
    elseif key == "scale" then
        return tbl:GetScale()
    elseif key == "localPosition" then
        return tbl:GetLocalPosition()
    elseif key == "eulerAngles" then
        return tbl:GetRotation()
    end
    return nil
end

Transform.__newindex = function(tbl, key, val)
    if key == "position" then
        return tbl:SetPosition(val)
    elseif key == "rotation" then
        return tbl:SetRotation(val)
    elseif key == "scale" then
        return tbl:SetScale(val)
    elseif key == "eulerAngles" then
        return tbl:SetRotation(val)
    end
    rawset(tbl, key, val)
end

-- ==========================================
-- GameObject
-- ==========================================
GameObject = {
    _instances = {}
}

function GameObject:New(name)
    local obj = {
        _name = name or "GameObject",
        _entity = 0,
        _type = "empty",
        _active = true,
        _components = {},
        _awoken = false,
        _started = false
    }
    setmetatable(obj, self)
    self.__index = self
    obj.transform = Transform:New(obj)
    table.insert(self._instances, obj)
    return obj
end

function GameObject:Find(name)
    for _, go in ipairs(self._instances) do
        if go._name == name then return go end
    end
    return nil
end

function GameObject:FindAll(name)
    local results = {}
    for _, go in ipairs(self._instances) do
        if go._name == name then table.insert(results, go) end
    end
    return results
end

function GameObject:GetName()
    return self._name
end

function GameObject:SetName(name)
    self._name = name
end

function GameObject:GetActive()
    return self._active
end

function GameObject:SetActive(active)
    self._active = active
end

function GameObject:AddComponent(componentClass, ...)
    local comp = componentClass:New(...)
    comp.gameObject = self
    comp.transform = self.transform
    table.insert(self._components, comp)
    return comp
end

function GameObject:GetComponent(componentClass)
    for _, comp in ipairs(self._components) do
        if getmetatable(comp) == componentClass then
            return comp
        end
    end
    return nil
end

function GameObject:GetComponentInChildren(componentClass)
    return self:GetComponent(componentClass)
end

function GameObject:GetComponents(componentClass)
    local results = {}
    for _, comp in ipairs(self._components) do
        if getmetatable(comp) == componentClass then
            table.insert(results, comp)
        end
    end
    return results
end

function GameObject:Destroy()
    if self._entity and self._entity > 0 then
        for _, comp in ipairs(self._components) do
            if comp.OnDestroy then pcall(comp.OnDestroy, comp) end
        end
        BlazeBolt.Destroy(self._entity)
        entityRegistry[self._entity] = nil
        self._entity = 0
    end
    self._active = false
    for i, go in ipairs(GameObject._instances) do
        if go == self then
            table.remove(GameObject._instances, i)
            break
        end
    end
end

-- ==========================================
-- SpriteRenderer Component
-- ==========================================
SpriteRenderer = Component:New()

function SpriteRenderer:New(texturePath)
    local obj = {
        _texturePath = texturePath or "",
        _color = Vector4(1, 1, 1, 1),
        _visible = true,
        _origin = Vector2(0.5, 0.5)
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function SpriteRenderer:Awake()
    local go = self.gameObject
    if go._entity and go._entity > 0 then
        if go._type == "sprite" then
            BlazeBolt.SpriteSetTexture(go._entity, self._texturePath)
            BlazeBolt.SpriteSetColor(go._entity, self._color)
            BlazeBolt.SpriteSetVisible(go._entity, self._visible)
            BlazeBolt.SpriteSetOrigin(go._entity, self._origin)
        end
    elseif self._texturePath and self._texturePath ~= "" then
        local pos = go.transform._position
        go._entity = BlazeBolt.CreateSprite(self._texturePath, pos)
        go._type = "sprite"
        if go._entity and go._entity > 0 then
            entityRegistry[go._entity] = go
            BlazeBolt.SpriteSetSize(go._entity, go.transform._scale)
            BlazeBolt.SpriteSetRotation(go._entity, go.transform._rotation)
            BlazeBolt.SpriteSetColor(go._entity, self._color)
            BlazeBolt.SpriteSetVisible(go._entity, self._visible)
            BlazeBolt.SpriteSetOrigin(go._entity, self._origin)
        end
    end
end

-- Property-style access
SpriteRenderer.__index = function(tbl, key)
    local raw = SpriteRenderer[key]
    if raw then return raw end
    if key == "color" then return tbl._color end
    if key == "texture" then return tbl._texturePath end
    if key == "visible" then return tbl._visible end
    if key == "origin" then return tbl._origin end
    return nil
end

SpriteRenderer.__newindex = function(tbl, key, val)
    if key == "color" then
        tbl._color = val
        local go = tbl.gameObject
        if go and go._entity and go._entity > 0 and go._type == "sprite" then
            BlazeBolt.SpriteSetColor(go._entity, val)
        end
        return
    elseif key == "texture" then
        tbl._texturePath = val
        local go = tbl.gameObject
        if go and go._entity and go._entity > 0 and go._type == "sprite" then
            BlazeBolt.SpriteSetTexture(go._entity, val)
        end
        return
    elseif key == "visible" then
        tbl._visible = val
        local go = tbl.gameObject
        if go and go._entity and go._entity > 0 and go._type == "sprite" then
            BlazeBolt.SpriteSetVisible(go._entity, val)
        end
        return
    elseif key == "origin" then
        tbl._origin = val
        local go = tbl.gameObject
        if go and go._entity and go._entity > 0 and go._type == "sprite" then
            BlazeBolt.SpriteSetOrigin(go._entity, val)
        end
        return
    end
    rawset(tbl, key, val)
end

-- ==========================================
-- AnimatedSpriteRenderer Component
-- ==========================================
AnimatedSpriteRenderer = Component:New()

function AnimatedSpriteRenderer:New(texturePath)
    local obj = {
        _texturePath = texturePath or "",
        _color = Vector4(1, 1, 1, 1),
        _looping = true,
        _playbackSpeed = 1,
        _playing = false
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function AnimatedSpriteRenderer:Awake()
    local go = self.gameObject
    if self._texturePath and self._texturePath ~= "" then
        local pos = go.transform._position
        go._entity = BlazeBolt.CreateAnimatedSprite(self._texturePath, pos)
        go._type = "animated_sprite"
        if go._entity and go._entity > 0 then
            entityRegistry[go._entity] = go
            BlazeBolt.AnimatedSpriteSetSize(go._entity, go.transform._scale)
            BlazeBolt.AnimatedSpriteSetRotation(go._entity, go.transform._rotation)
            BlazeBolt.AnimatedSpriteSetColor(go._entity, self._color)
            BlazeBolt.AnimatedSpriteSetLooping(go._entity, self._looping)
            BlazeBolt.AnimatedSpriteSetPlaybackSpeed(go._entity, self._playbackSpeed)
        end
    end
end

function AnimatedSpriteRenderer:Play()
    self._playing = true
    local go = self.gameObject
    if go and go._entity and go._entity > 0 then
        BlazeBolt.AnimatedSpritePlay(go._entity)
    end
end

function AnimatedSpriteRenderer:Stop()
    self._playing = false
    local go = self.gameObject
    if go and go._entity and go._entity > 0 then
        BlazeBolt.AnimatedSpriteStop(go._entity)
    end
end

-- ==========================================
-- TextRenderer Component
-- ==========================================
TextRenderer = Component:New()

function TextRenderer:New(fontPath, text)
    local obj = {
        _fontPath = fontPath or "",
        _text = text or "",
        _color = Vector4(1, 1, 1, 1),
        _visible = true,
        _alignment = TextAlignment.LEFT
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function TextRenderer:Awake()
    local go = self.gameObject
    if self._fontPath and self._fontPath ~= "" then
        local pos = go.transform._position
        go._entity = BlazeBolt.CreateText(self._fontPath, self._text, pos)
        go._type = "text"
        if go._entity and go._entity > 0 then
            entityRegistry[go._entity] = go
            BlazeBolt.TextSetColor(go._entity, self._color)
            BlazeBolt.TextSetScale(go._entity, go.transform._scale)
            BlazeBolt.TextSetRotation(go._entity, go.transform._rotation)
            BlazeBolt.TextSetVisible(go._entity, self._visible)
        end
    end
end

-- ==========================================
-- Camera Component
-- ==========================================
Camera = Component:New()

function Camera:New()
    local obj = {
        _zoom = 1,
        _active = true,
        _clearColor = Vector4(0, 0, 0, 1)
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function Camera:Awake()
    local go = self.gameObject
    go._entity = BlazeBolt.CreateCamera()
    go._type = "camera"
    if go._entity and go._entity > 0 then
        entityRegistry[go._entity] = go
        BlazeBolt.CameraSetPosition(go._entity, go.transform._position)
        BlazeBolt.CameraSetZoom(go._entity, self._zoom)
        BlazeBolt.CameraSetRotation(go._entity, go.transform._rotation)
    end
end

-- ==========================================
-- ParticleSystem Component
-- ==========================================
ParticleSystem = Component:New()

function ParticleSystem:New()
    local obj = {
        _texture = "",
        _emissionRate = 10,
        _active = true,
        _visible = true
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function ParticleSystem:Awake()
    local go = self.gameObject
    go._entity = BlazeBolt.CreateParticleSystem()
    go._type = "particle_system"
    if go._entity and go._entity > 0 then
        entityRegistry[go._entity] = go
        BlazeBolt.ParticleSystemSetPosition(go._entity, go.transform._position)
        if self._texture and self._texture ~= "" then
            BlazeBolt.ParticleSystemSetTexture(go._entity, self._texture)
        end
        BlazeBolt.ParticleSystemSetEmissionRate(go._entity, self._emissionRate)
        BlazeBolt.ParticleSystemSetActive(go._entity, self._active)
        BlazeBolt.ParticleSystemSetVisible(go._entity, self._visible)
    end
end

-- ==========================================
-- Light Component
-- ==========================================
Light = Component:New()

function Light:New(lightType)
    local obj = {
        _lightType = lightType or "point",
        _color = Vector3(1, 1, 1),
        _intensity = 1,
        _radius = 200,
        _enabled = true
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function Light:Awake()
    local go = self.gameObject
    if self._lightType == "point" then
        go._entity = BlazeBolt.CreatePointLight(
            go.transform._position.x, go.transform._position.y,
            self._color.x, self._color.y, self._color.z,
            self._intensity, self._radius)
        go._type = "point_light"
    else
        go._entity = BlazeBolt.CreateAmbientLight(
            self._color.x, self._color.y, self._color.z,
            self._intensity)
        go._type = "ambient_light"
    end
    if go._entity and go._entity > 0 then
        entityRegistry[go._entity] = go
        BlazeBolt.LightSetEnabled(go._entity, self._enabled)
    end
end

-- ==========================================
-- Tileset Component
-- ==========================================
Tileset = Component:New()

function Tileset:New(texturePath, tileW, tileH, atlasCols, atlasRows)
    local obj = {
        _texturePath = texturePath or "",
        _tileWidth = tileW or 32,
        _tileHeight = tileH or 32,
        _atlasCols = atlasCols or 8,
        _atlasRows = atlasRows or 8
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function Tileset:Awake()
    local go = self.gameObject
    if self._texturePath and self._texturePath ~= "" then
        go._entity = BlazeBolt.CreateTileset(
            self._texturePath, self._tileWidth, self._tileHeight,
            self._atlasCols, self._atlasRows)
        go._type = "tileset"
        if go._entity and go._entity > 0 then
            entityRegistry[go._entity] = go
            BlazeBolt.TilesetSetPosition(go._entity, go.transform._position)
        end
    end
end

-- ==========================================
-- AudioSource Component
-- ==========================================
AudioSource = Component:New()

function AudioSource:New(soundName)
    local obj = {
        _soundName = soundName or "",
        _volume = 1,
        _loop = false,
        _playing = false,
        _soundId = -1
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function AudioSource:Play()
    if self._soundName and self._soundName ~= "" then
        BlazeBolt.SetSoundVolume(self._soundName, self._volume)
        BlazeBolt.PlaySound(self._soundName)
        self._playing = true
    end
end

function AudioSource:Stop()
    if self._soundName and self._soundName ~= "" then
        BlazeBolt.StopSound(self._soundName)
        self._playing = false
    end
end

-- ==========================================
-- PhysicsBody Component
-- ==========================================
PhysicsBody = Component:New()

function PhysicsBody:New(bodyType)
    local obj = {
        _bodyType = bodyType or 1,
        _mass = 1,
        _friction = 0.3,
        _restitution = 0.5,
        _colliderShape = "circle",
        _circleRadius = 32,
        _rectHalfWidth = 32,
        _rectHalfHeight = 32,
        _gravityScale = 1,
        _fixedRotation = false,
        _bodyEntity = 0,
        _awoken = false
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function PhysicsBody:Awake()
    local go = self.gameObject
    local pos = go.transform._position
    self._bodyEntity = BlazeBolt.PhysicsCreateBody(
        self._bodyType, pos.x, pos.y,
        self._mass, self._friction, self._restitution)
    if self._bodyEntity and self._bodyEntity > 0 then
        if self._colliderShape == "circle" then
            BlazeBolt.PhysicsAddCircle(self._bodyEntity, self._circleRadius, 0, 0)
        else
            BlazeBolt.PhysicsAddRectangle(self._bodyEntity, self._rectHalfWidth, self._rectHalfHeight)
        end
        BlazeBolt.PhysicsSetGravityScale(self._bodyEntity, self._gravityScale)
        BlazeBolt.PhysicsSetFixedRotation(self._bodyEntity, self._fixedRotation)
    end
end

function PhysicsBody:Update(dt)
    if self._bodyEntity and self._bodyEntity > 0 and self.gameObject._entity and self.gameObject._entity > 0 then
        local go = self.gameObject
        if go._type == "sprite" then
            BlazeBolt.PhysicsSyncSprite(self._bodyEntity, go._entity)
        elseif go._type == "text" then
            BlazeBolt.PhysicsSyncText(self._bodyEntity, go._entity)
        elseif go._type == "animated_sprite" then
            BlazeBolt.PhysicsSyncAnimatedSprite(self._bodyEntity, go._entity)
        end
    end
end

-- ==========================================
-- Lifecycle management
-- ==========================================
local function callAwake(go)
    if not go._awoken then
        go._awoken = true
        for _, comp in ipairs(go._components) do
            if comp.Awake then pcall(comp.Awake, comp) end
        end
    end
end

local function callStart(go)
    if not go._started then
        go._started = true
        for _, comp in ipairs(go._components) do
            if comp.Start then pcall(comp.Start, comp) end
        end
    end
end

-- Override the user's Update function to add lifecycle management
local _userUpdate = nil
if type(Update) == "function" then
    _userUpdate = Update
end

local _userDraw = nil
if type(Draw) == "function" then
    _userDraw = Draw
end

Update = function(dt)
    Time._deltaTime = dt
    Time._time = Time._time + dt
    Time._frameCount = Time._frameCount + 1

    for _, go in ipairs(GameObject._instances) do
        if go._active then
            callAwake(go)
            callStart(go)
            for _, comp in ipairs(go._components) do
                if comp.Update then
                    local ok, err = pcall(comp.Update, comp, dt)
                    if not ok then
                        print("Error in " .. tostring(go._name) .. ".Update: " .. tostring(err))
                    end
                end
            end
        end
    end

    if _userUpdate then
        _userUpdate(dt)
    end
end

Draw = function()
    for _, go in ipairs(GameObject._instances) do
        if go._active then
            callAwake(go)
            callStart(go)
        end
    end
    if _userDraw then
        _userDraw()
    end
end

-- ==========================================
-- Physics static class
-- ==========================================
Physics = {}

function Physics:Init(gravityX, gravityY)
    BlazeBolt.PhysicsInit(gravityX or 0, gravityY or -9.81)
end

function Physics:SetGravity(x, y)
    BlazeBolt.PhysicsSetGravity(x, y)
end

function Physics:Step()
    BlazeBolt.PhysicsStep()
end

function Physics:Raycast(originX, originY, directionX, directionY)
    error("Physics.Raycast not yet implemented")
end

-- ==========================================
-- Audio static class
-- ==========================================
Audio = {}

function Audio:Load(path, name, loop)
    return BlazeBolt.LoadSound(path, name, loop)
end

function Audio:Play(name)
    BlazeBolt.PlaySound(name)
end

function Audio:Stop(name)
    BlazeBolt.StopSound(name)
end

function Audio:StopAll()
    BlazeBolt.StopAllSounds()
end

function Audio:SetVolume(name, volume)
    BlazeBolt.SetSoundVolume(name, volume)
end

function Audio:IsPlaying(name)
    return BlazeBolt.IsSoundPlaying(name)
end

print("[BlazeBolt Runtime] Unity-like API loaded")
print("  - GameObject, Transform, Component, Input, Time, Mathf, Random")
print("  - SpriteRenderer, TextRenderer, Camera, ParticleSystem, Light")
print("  - AudioSource, PhysicsBody")
print("  - Use GameObject:New('name') to create objects")
